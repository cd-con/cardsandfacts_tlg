#Конфигурационный файл. Для внут. пользования
configPath = 'configuration.cfg'